package com.atm;

import java.util.Scanner;

class ATM extends UserBankAccount {
    int useraccount ; 

    public ATM() {
        System.out.println("Welcome to ATM.");
    }

    // Method to display the ATM menu and handle user interactions
    public void start() {
    	System.out.println("Start: ");
        Scanner sc = new Scanner(System.in);

        while (true) {
            // Display ATM menu
            System.out.println("Automated Teller Machine");
            System.out.println("Choose 1 for Withdraw");
            System.out.println("Choose 2 for Deposit");
            System.out.println("Choose 3 for Check Balance");
            System.out.println("Choose 4 for EXIT");
            System.out.print("Choose the operation you want to perform: ");

            // Get user's choice
            int choice = sc.nextInt();

            switch (choice) {
                case 1:
                    System.out.print("Enter amount to withdraw: ");
                    int withdrawAmount = sc.nextInt();
                    withdraw(withdrawAmount); 
                    break;

                case 2:
                    // Deposit money to account 
                    System.out.print("Enter amount to deposit: ");
                    int depositAmount = sc.nextInt();
                    deposit(depositAmount);  
                    break;

                case 3:
                    // Check balance
                    System.out.println("Current balance: " + checkBalance());
                    break;

                case 4:
                    // Exit the ATM
                    System.out.println("Thank you for using the ATM. Goodbye!");
                    sc.close();
                    return;

                default:
                    // Handle invalid input
                    System.out.println("Invalid option! Please try again.");
                    break;
            }
        }
    }

}
