package com.atm;
import java.util.Scanner;

class UserBankAccount {
    private int balance;  

    public void setInitialBalance() {
        System.out.println("Enter your Initial Balance: ");
        Scanner sc = new Scanner(System.in);
        this.balance = sc.nextInt();  
        
    }

    public void deposit(int amount) {
        if (amount > 0) {
            balance += amount;
            System.out.println("Amount deposited: " + amount);
        } else {
            System.out.println("Invalid deposit amount!");
        }
    }

    public void withdraw(int amount) {
        if (amount > 0 && amount <= balance) {
            balance -= amount;
            System.out.println("Amount withdrawn: " + amount);
        } else if (amount > balance) {
            System.out.println("Insufficient balance for withdrawal!");
        } else {
            System.out.println("Invalid withdrawal amount!");
        }
        
    }

    public int checkBalance() {
        return balance;
    }
  
}




