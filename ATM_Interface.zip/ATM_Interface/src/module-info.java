/**
 * 
 */
/**
 * 
 */
module ATM_Interface {
}