package com.game;
import java.util.Scanner;
import java.lang.Math;

public class GuessTheNumber {
	static int random_number=0;
	static int score=10;
	static int max_attempts=0;
	static int current_attempt=0;
	static boolean canTryAgain = false;
	
	public static void play(boolean isNewGame, int additional_attempts) {
		Scanner sc = new Scanner(System.in);
		if(isNewGame) {
		random_number = 1 + (int)(Math.random()*100);
		score=10;
		max_attempts=5;
		current_attempt=0;
		System.out.println("Starting a new game...");
		} else {
		max_attempts += additional_attempts;
		}
		while(max_attempts != 0) {
			System.out.println("Enter your guess:");
			int user_guess = sc.nextInt();
			current_attempt++;
			
			if (user_guess == random_number) {
				System.out.println("Your guess is correct. You won the Game!");
				System.out.println("Score: "+score);
				return;
				}
			else if(user_guess > random_number && current_attempt != max_attempts-1) {
				System.out.println("Your guess is too high!");
				score--;
			}
			else if(user_guess < random_number && current_attempt != max_attempts-1) {
				System.out.println("Your guess is too low!");
				score--;
			}
			else {
				if(current_attempt == max_attempts-1) {
					System.out.println("You have used all your " + max_attempts + "attempts");
					System.out.println("Score: 0");
					return;
				}
			}
		}
	}
	
			
			public static void main(String[] args) {
				Scanner sc = new Scanner(System.in);
				boolean isFirstGame = true;
				while(true) {
					int choice;
					
					if(isFirstGame) {
						choice = 1;
						isFirstGame = false;
					} else {
						System.out.println("Enter your choice: 1) Start game... 2) Try again 3)Exist");
						choice = sc.nextInt();
						switch(choice){
						case 1:
							System.out.println("Start play...");
					        play(true,0);
					        canTryAgain = true;
					        break;
				        case 2:
				        	if(current_attempt>0 && canTryAgain) {
					        System.out.println("Try Again you only have 3 more attempts!");
					        play(false,3);
					        canTryAgain = false;
				        	} else if(!canTryAgain && current_attempt>0) {
				        		System.out.println("You can only choose try again 1 time per new game.");
				        	}
				        	else {
				        		System.out.println("You must start a game before trying again!");
				        	}
				        	break;
				        case 3:
					        System.out.println("Exit");
					        return;
					    default:
					    	System.out.println("Invalid Choice!");
					    	break;
					        }
						}
				}
			}
}
