package com.calculator;
import java.util.Scanner;

public class GradeCalculator {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter Student Name: ");
		String name = sc.nextLine();
		
		System.out.println("Enter marks for subjects English, Maths, Python, Java, SoftSkills");
		float english = sc.nextFloat();
		float maths = sc.nextFloat();
		float python = sc.nextFloat();
		float java = sc.nextFloat();
		float softskills = sc.nextFloat();
		float total_marks = (english+maths+python+java+softskills);
		System.out.println("Total Marks: " +total_marks);
		float average_marks = total_marks/5;
		System.out.println("Average Marks: "+average_marks);
	
		char grade;
		if(average_marks>=80) {
			grade = 'A';
			System.out.println("Grade A\n"+"Excellent");
		}
		else if(average_marks>=70) {
			grade = 'B';
			System.out.println("Grade B\n"+"Good");
		}
		else if(average_marks>=60) {
			grade = 'C';
			System.out.println("Grade C\n"+"average");
		}
		else if(average_marks>=45) {
			grade = 'D';
			System.out.println("Grade D\n"+"Just Pass");
		}
		else {
			grade = 'E';
			System.out.println("Grade E\n"+"Fail\n");
		}
		sc.close();


	}
	
}
