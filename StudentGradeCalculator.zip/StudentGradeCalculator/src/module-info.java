/**
 * 
 */
/**
 * 
 */
module StudentGradeCalculator {
}